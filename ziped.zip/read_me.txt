Notice:
	this project is build for mini project of subject skill devolopment lab subject of computer branch in third year by mahajan nilesh navnath for use of this project or make any modification see bottom for conatct info. 

About This project:
	this project contail  139 python files
	it generate images dynamically so conting of image is not possible
 
	this is web based project so it nust need to run the server first by runserver and porn number passing to manage.py file this file start server at localhost with asign port number

	then we can access this priject from any browser from same system

	ex: we run server as python manage.py runserver 80
		mean server start at port no 80
		for use it enter url as http://127.0.0.1:80/view in browser
		there is no initial root file in project so it must /view directory  asign after port otherwise it show 404 error
	
REQUIREMENTS**
		PYTHON 3.7.0 64 bit 	
	in system the require python librarys must be instaled 
		1] Django      2.1.1
		2] csv        
		3] matplotlib  2.2.3
		4] os
		5] datetime
		6] sqlite      3.0.0

Extra Packeges:		
	there is some user created pacakage name as graphs use for ploting some user define graph

How To RUN/START:
	* before run read all requirments mention above
	1] Open Terminal 
	2] Change Directary to project root where manage.py file present
	3] now run command python manage.py port_no
	4] now access it from browser as http://127.0.0.1:80/view
How To STOP:
	1] enter command ctrl+c/ctrl+z
	

============== Eroor ==============
	if the version of python or its library is not as per this project use so there may be chance of some error may occure at that time some syntax updation require
=================================================


Conatact Details:
	Name: Mahajan Nilesh Navnath
	Email:nileshnmahajan@gmail.command
	website:https://kkbuilds.com/
	cont: +919975720525
	