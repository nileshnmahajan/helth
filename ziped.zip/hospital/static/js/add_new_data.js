document.getElementById('help').onmouseover = function(){
    document.getElementById('view_help').style.display = 'block';
}
document.getElementById('help').onmouseout = function(){
    document.getElementById('view_help').style.display = 'none';
}